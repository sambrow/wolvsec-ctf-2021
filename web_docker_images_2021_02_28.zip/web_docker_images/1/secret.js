exports.flag = 'GLSC{un1c0d3_ch4r4c73r5_4r3_1n73r3571n9}';
