exports.flag = 'GLSC{pr0707yp3_p011u710n_f0r_7h3_w1n}';
