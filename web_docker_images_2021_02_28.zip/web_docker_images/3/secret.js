exports.flag = 'GLSC{7wo_p@r@m5_@re_6e77er_7h@n_one}';
